// server.js
'use strict';

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const multer     = require('multer');
const sharp      = require('sharp');
const fs         = require('fs');
const path       = require('path');
const { spawn }  = require('child_process');
const archiver   = require('archiver');
const CONFIG     = require('./config');

// ─── 경로 상수 ────────────────────────────────────────────────
const PUBLIC_DIR  = path.join(__dirname, 'public');
const UPLOAD_DIR  = path.join(PUBLIC_DIR, 'uploads');
const BACKUP_DIR  = path.join(PUBLIC_DIR, 'uploads', 'backup');
const DB_PATH     = path.join(__dirname, 'database.json');

[UPLOAD_DIR, BACKUP_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ─── Express + Socket.io ──────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const io     = new Server(server);

app.use(express.static(PUBLIC_DIR));

// ─── database.json 관리 ──────────────────────────────────────
function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function loadDB() {
  if (!fs.existsSync(DB_PATH)) return initDB();
  try { return JSON.parse(fs.readFileSync(DB_PATH, 'utf8')); }
  catch { return initDB(); }
}

function initDB() {
  const activeSlots = CONFIG.grid
    .filter(t => t.active)
    .map(t => ({ id: t.id, filled: false, imagePath: null, timestamp: null }));

  const db = { date: todayKey(), slots: activeSlots };
  saveDB(db);
  return db;
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// 날짜 달라졌으면 백업 후 리셋
async function checkAndReset() {
  const db = loadDB();
  if (db.date === todayKey()) return db;

  console.log(`[RESET] 날짜 변경 감지: ${db.date} → ${todayKey()}`);

  // 어제 업로드 폴더 압축 백업
  await backupUploads(db.date);

  // 업로드 폴더 정리 (backup 폴더 제외)
  const files = fs.readdirSync(UPLOAD_DIR);
  for (const f of files) {
    if (f === 'backup') continue;
    fs.rmSync(path.join(UPLOAD_DIR, f), { recursive: true, force: true });
  }

  // 오래된 백업 삭제
  cleanOldBackups();

  return initDB();
}

function backupUploads(dateStr) {
  return new Promise((resolve) => {
    const zipPath = path.join(BACKUP_DIR, `${dateStr}.zip`);
    const output  = fs.createWriteStream(zipPath);
    const archive = archiver('zip', { zlib: { level: 6 } });

    output.on('close', resolve);
    archive.on('error', resolve); // 에러나도 계속 진행

    archive.pipe(output);
    // backup 폴더 제외하고 uploads 안 파일만 압축
    const files = fs.readdirSync(UPLOAD_DIR).filter(f => f !== 'backup');
    files.forEach(f => {
      const fp = path.join(UPLOAD_DIR, f);
      if (fs.statSync(fp).isFile()) archive.file(fp, { name: f });
    });
    archive.finalize();
  });
}

function cleanOldBackups() {
  const keepMs = CONFIG.server.backup_keep_days * 86400 * 1000;
  const now    = Date.now();
  const files  = fs.readdirSync(BACKUP_DIR);
  for (const f of files) {
    const fp  = path.join(BACKUP_DIR, f);
    const age = now - fs.statSync(fp).mtimeMs;
    if (age > keepMs) fs.rmSync(fp, { force: true });
  }
}

// ─── multer 설정 ─────────────────────────────────────────────
const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.jpg';
    cb(null, `${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`);
  },
});
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  fileFilter: (req, file, cb) => {
    cb(null, /image\/(jpeg|png|webp|heic)/.test(file.mimetype));
  },
});

// ─── 업로드 엔드포인트 ────────────────────────────────────────
app.post('/upload', upload.single('photo'), async (req, res) => {
  try {
    const db = loadDB();

    // 빈 슬롯 찾기
    const emptySlots = db.slots.filter(s => !s.filled);
    if (emptySlots.length === 0) {
      return res.json({ ok: false, message: '오늘 모든 칸이 채워졌습니다!' });
    }

    // 랜덤 슬롯 배정
    const slot = emptySlots[Math.floor(Math.random() * emptySlots.length)];

    // 리사이징 (긴 변 기준 thumbnail_size px)
    const originalPath  = req.file.path;
    const thumbFilename = `thumb_${req.file.filename}`;
    const thumbPath     = path.join(UPLOAD_DIR, thumbFilename);

    await sharp(originalPath)
      .resize(CONFIG.server.thumbnail_size, CONFIG.server.thumbnail_size, {
        fit: 'inside', withoutEnlargement: true,
      })
      .jpeg({ quality: 85 })
      .toFile(thumbPath);

    // 원본 삭제 (썸네일만 보관)
    fs.rmSync(originalPath, { force: true });

    // DB 업데이트
    const webPath = `/uploads/${thumbFilename}`;
    slot.filled    = true;
    slot.imagePath = webPath;
    slot.timestamp = new Date().toISOString();
    saveDB(db);

    // Socket.io 브로드캐스트 → display.html
    const gridInfo = CONFIG.grid.find(g => g.id === slot.id);
    io.emit('new_photo', {
      slotId:    slot.id,
      imagePath: webPath,
      row:       gridInfo.row,
      col:       gridInfo.col,
      x: gridInfo.x, y: gridInfo.y,
      w: gridInfo.w, h: gridInfo.h,
      totalFilled: db.slots.filter(s => s.filled).length,
      totalSlots:  db.slots.length,
    });

    res.json({
      ok:          true,
      slotId:      slot.id,
      row:         gridInfo.row + 1,
      col:         gridInfo.col + 1,
      imagePath:   webPath,
      totalFilled: db.slots.filter(s => s.filled).length,
      totalSlots:  db.slots.length,
    });

  } catch (err) {
    console.error('[UPLOAD ERROR]', err);
    res.status(500).json({ ok: false, message: '서버 오류' });
  }
});

// ─── 현재 슬롯 상태 조회 (display.html 초기 로드용) ──────────
app.get('/api/slots', (req, res) => {
  const db = loadDB();
  const result = db.slots.map(s => {
    const g = CONFIG.grid.find(g => g.id === s.id);
    return { ...s, ...g };
  });
  res.json({
    slots:       result,
    totalFilled: db.slots.filter(s => s.filled).length,
    totalSlots:  db.slots.length,
    date:        db.date,
  });
});

// ─── Cloudflare 터널 URL 파싱 ────────────────────────────────
let tunnelUrl = null;

function startTunnel() {
  console.log('[TUNNEL] Cloudflare 터널 시작 중...');
  const cf = spawn('cloudflared', [
    'tunnel', '--url', `http://localhost:${CONFIG.server.port}`
  ]);

  const parseUrl = (data) => {
    const str = data.toString();
    // trycloudflare.com URL 파싱
    const match = str.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);
    if (match && !tunnelUrl) {
      tunnelUrl = match[0];
      console.log(`[TUNNEL] URL 확정: ${tunnelUrl}`);
      // 연결된 모든 클라이언트에 URL 전송
      io.emit('tunnel_url', { url: tunnelUrl });
    }
  };

  cf.stdout.on('data', parseUrl);
  cf.stderr.on('data', parseUrl);
  cf.on('close', (code) => {
    console.log(`[TUNNEL] 종료 (code: ${code}), 10초 후 재시작...`);
    tunnelUrl = null;
    setTimeout(startTunnel, 10000);
  });
}

// ─── Socket.io 연결 ──────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[WS] 클라이언트 연결: ${socket.id}`);

  // 연결 즉시 현재 터널 URL 전송 (이미 있으면)
  if (tunnelUrl) socket.emit('tunnel_url', { url: tunnelUrl });

  socket.on('disconnect', () => {
    console.log(`[WS] 클라이언트 해제: ${socket.id}`);
  });
});

// ─── 서버 시작 ───────────────────────────────────────────────
async function main() {
  // 날짜 리셋 체크
  await checkAndReset();

  server.listen(CONFIG.server.port, () => {
    console.log(`[SERVER] http://localhost:${CONFIG.server.port}`);
    console.log(`[SERVER] display: http://localhost:${CONFIG.server.port}/display.html`);
    console.log(`[SERVER] guide:   http://localhost:${CONFIG.server.port}/guide.html`);

    // 터널 시작
    startTunnel();
  });
}

main().catch(console.error);

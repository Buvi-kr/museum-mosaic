// extract_coords.js
// 사용법: node extract_coords.js
// target_mask.png 픽셀을 7×4 격자로 분석해서
// 활성 슬롯(흰색)을 config.js grid 형식으로 출력해줌

const sharp = require('sharp');
const path  = require('path');

const MASK_PATH = path.join(__dirname, 'public', 'target_mask.png');
const COLS = 7;
const ROWS = 4;
// 흰색 판정 기준 (0~255, 이 값 이상이면 흰색으로 간주)
const WHITE_THRESHOLD = 180;

async function extract() {
  const { data, info } = await sharp(MASK_PATH)
    .resize(COLS, ROWS, { fit: 'fill' })  // 7×4 픽셀로 다운샘플
    .raw()
    .toBuffer({ resolveWithObject: true });

  const channels = info.channels; // 3(RGB) or 4(RGBA)
  const grid = [];

  for (let row = 0; row < ROWS; row++) {
    for (let col = 0; col < COLS; col++) {
      const idx = (row * COLS + col) * channels;
      const r = data[idx];
      const g = data[idx + 1];
      const b = data[idx + 2];
      const brightness = (r + g + b) / 3;
      const active = brightness >= WHITE_THRESHOLD;

      const x = parseFloat((col / COLS).toFixed(4));
      const y = parseFloat((row / ROWS).toFixed(4));
      const w = parseFloat((1 / COLS).toFixed(4));
      const h = parseFloat((1 / ROWS).toFixed(4));

      grid.push(
        `    { id: ${String(row * COLS + col).padStart(2)}, row: ${row}, col: ${col},` +
        ` x: ${x.toFixed(4)}, y: ${y.toFixed(4)}, w: ${w.toFixed(4)}, h: ${h.toFixed(4)},` +
        ` active: ${active ? 'true ' : 'false'} },  // 밝기: ${Math.round(brightness)}`
      );
    }
  }

  const activeCount = grid.filter(l => l.includes('true')).length;

  console.log('\n=== config.js grid 배열 (복붙용) ===\n');
  console.log('  grid: [');
  grid.forEach(l => console.log(l));
  console.log('  ],');
  console.log(`\n활성 슬롯 수: ${activeCount} / ${COLS * ROWS}`);
  console.log('위 내용을 config.js의 grid: [...] 부분에 붙여넣으세요.\n');
}

extract().catch(e => {
  console.error('오류:', e.message);
  console.error('target_mask.png가 public/ 폴더에 있는지 확인하세요.');
});

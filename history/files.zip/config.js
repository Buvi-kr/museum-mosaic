// config.js
// 여기만 수정하면 에셋 교체·격자 변경 가능. 코드 건드릴 필요 없음.

const CONFIG = {

  server: {
    port: 3000,
    thumbnail_size: 600,      // 업로드 사진 리사이즈 px (긴 변 기준)
    backup_keep_days: 7,      // 백업 보관 일수
  },

  canvas: {
    width:  1920,
    height: 1080,
  },

  assets: {
    bg:      'bg.jpg',           // 우주 배경
    mask:    'target_mask.png',  // 망원경 내부=흰색, 외부=투명
    outline: 'target_outline.png', // 망원경 윤곽선만
  },

  blend: {
    outline_alpha: 0.85,   // 윤곽선 불투명도 (0~1)
  },

  // 7×4 격자 — 비율값 (실제px = x * canvas.width)
  // active: false 칸은 슬롯 등록 안 됨 (배경만 보임)
  // ※ target_mask.png 확정 후 extract_coords.js 로 자동 재생성 가능
  grid: [
    // row 0 — 경통 상단
    { id:  0, row: 0, col: 0, x: 0.000, y: 0.000, w: 0.1428, h: 0.25, active: false },
    { id:  1, row: 0, col: 1, x: 0.1428,y: 0.000, w: 0.1428, h: 0.25, active: false },
    { id:  2, row: 0, col: 2, x: 0.2856,y: 0.000, w: 0.1428, h: 0.25, active: true  },
    { id:  3, row: 0, col: 3, x: 0.4284,y: 0.000, w: 0.1428, h: 0.25, active: true  },
    { id:  4, row: 0, col: 4, x: 0.5712,y: 0.000, w: 0.1428, h: 0.25, active: true  },
    { id:  5, row: 0, col: 5, x: 0.7140,y: 0.000, w: 0.1428, h: 0.25, active: false },
    { id:  6, row: 0, col: 6, x: 0.8568,y: 0.000, w: 0.1428, h: 0.25, active: false },
    // row 1 — 경통 중단
    { id:  7, row: 1, col: 0, x: 0.000, y: 0.25,  w: 0.1428, h: 0.25, active: false },
    { id:  8, row: 1, col: 1, x: 0.1428,y: 0.25,  w: 0.1428, h: 0.25, active: true  },
    { id:  9, row: 1, col: 2, x: 0.2856,y: 0.25,  w: 0.1428, h: 0.25, active: true  },
    { id: 10, row: 1, col: 3, x: 0.4284,y: 0.25,  w: 0.1428, h: 0.25, active: true  },
    { id: 11, row: 1, col: 4, x: 0.5712,y: 0.25,  w: 0.1428, h: 0.25, active: true  },
    { id: 12, row: 1, col: 5, x: 0.7140,y: 0.25,  w: 0.1428, h: 0.25, active: true  },
    { id: 13, row: 1, col: 6, x: 0.8568,y: 0.25,  w: 0.1428, h: 0.25, active: false },
    // row 2 — 경통 하단 + 가대
    { id: 14, row: 2, col: 0, x: 0.000, y: 0.50,  w: 0.1428, h: 0.25, active: true  },
    { id: 15, row: 2, col: 1, x: 0.1428,y: 0.50,  w: 0.1428, h: 0.25, active: true  },
    { id: 16, row: 2, col: 2, x: 0.2856,y: 0.50,  w: 0.1428, h: 0.25, active: true  },
    { id: 17, row: 2, col: 3, x: 0.4284,y: 0.50,  w: 0.1428, h: 0.25, active: true  },
    { id: 18, row: 2, col: 4, x: 0.5712,y: 0.50,  w: 0.1428, h: 0.25, active: true  },
    { id: 19, row: 2, col: 5, x: 0.7140,y: 0.50,  w: 0.1428, h: 0.25, active: true  },
    { id: 20, row: 2, col: 6, x: 0.8568,y: 0.50,  w: 0.1428, h: 0.25, active: true  },
    // row 3 — 삼각대
    { id: 21, row: 3, col: 0, x: 0.000, y: 0.75,  w: 0.1428, h: 0.25, active: false },
    { id: 22, row: 3, col: 1, x: 0.1428,y: 0.75,  w: 0.1428, h: 0.25, active: false },
    { id: 23, row: 3, col: 2, x: 0.2856,y: 0.75,  w: 0.1428, h: 0.25, active: true  },
    { id: 24, row: 3, col: 3, x: 0.4284,y: 0.75,  w: 0.1428, h: 0.25, active: true  },
    { id: 25, row: 3, col: 4, x: 0.5712,y: 0.75,  w: 0.1428, h: 0.25, active: true  },
    { id: 26, row: 3, col: 5, x: 0.7140,y: 0.75,  w: 0.1428, h: 0.25, active: false },
    { id: 27, row: 3, col: 6, x: 0.8568,y: 0.75,  w: 0.1428, h: 0.25, active: false },
  ],
};

module.exports = CONFIG;

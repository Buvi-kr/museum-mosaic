@echo off
chcp 65001 > nul
title 포천아트밸리 모자이크 시스템

cd /d C:\museum-mosaic

echo [1/4] Node.js 서버 시작...
start "모자이크 서버" cmd /k node server.js

echo [2/4] 잠시 대기...
timeout /t 3 /nobreak > nul

echo [3/4] Cloudflare 터널 시작...
start "Cloudflare 터널" cmd /k cloudflared tunnel --url http://localhost:3000

echo [4/4] 터널 URL 확정 대기 (6초)...
timeout /t 6 /nobreak > nul

echo 크롬 실행...
start chrome --kiosk --app=http://localhost:3000/guide.html
timeout /t 1 /nobreak > nul
start chrome --kiosk --app=http://localhost:3000/display.html

echo.
echo ✅ 시스템 시작 완료
echo    서버:    http://localhost:3000
echo    안내:    http://localhost:3000/guide.html
echo    전시:    http://localhost:3000/display.html
